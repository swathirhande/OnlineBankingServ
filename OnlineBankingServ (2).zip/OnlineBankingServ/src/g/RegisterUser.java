package g;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterUser {
	static int status = 0;

	//Date date = new Date();
   // Timestamp timestamp = new Timestamp(date.getTime());  
	public static int register(String username, String password, String repassword, double amount, String adderess, double phone) {
		
		Connection con=GetCon.getCon();
		 if(con== null)
		 {
			 System.out.println("con is NULL");
		 }
		
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("Insert into newaccount values(?,?,?,?,?,?,?,?)");
			ps.setInt(1, 0);
			ps.setString(2, username);
			ps.setString(3, password);
			ps.setString(4, repassword);
			ps.setDouble(5, amount);
			ps.setString(6, adderess);
			ps.setDouble(7, phone);
			//ps.setTimestamp(8,timestamp );

			status = ps.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;

	}
}
