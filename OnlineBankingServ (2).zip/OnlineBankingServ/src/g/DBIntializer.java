package g;

public interface DBIntializer {
	String DRIVER = "com.mysql.cj.jdbc.Driver";
	String CON_STRING = "jdbc:mysql://localhost:3306/nmit?useUnicode=true&characterEncoding=UTF-8&useFastDateParsing=false";
	String USERNAME = "root";
	String PASSWORD = "swathi98!";
}
